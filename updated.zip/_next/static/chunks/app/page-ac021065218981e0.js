(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1931],
  {
    1390: function (s, e, a) {
      Promise.resolve().then(a.bind(a, 4281));
    },
    4281: function (s, e, a) {
      "use strict";
      a.r(e),
        a.d(e, {
          default: function () {
            return t;
          },
        });
      var i = a(7437),
        l = a(7887),
        c = () =>
          (0, i.jsx)("div", {
            className: "offer-card-area",
            children: (0, i.jsxs)("div", {
              className:
                "row no-gap row-cols-xxl-5 row-cols-xl-4 row-cols-lg-3 row-cols-sm-2 row-cols-1 justify-content-center",
              children: [
                (0, i.jsx)("div", {
                  className: "col",
                  "data-aos": "fade-up",
                  "data-aos-duration": 1500,
                  "data-aos-offset": 50,
                  children: (0, i.jsxs)("div", {
                    className: "offer-card-item",
                    children: [
                      (0, i.jsx)("img", {
                        src: "assets/images/offer/good-food.png",
                        alt: "Good Food",
                      }),
                      (0, i.jsx)("div", {
                        className: "badge",
                        children: "Hot",
                      }),
                      (0, i.jsx)("div", {
                        className: "image",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/offer/offer-card1.png",
                          alt: "Food",
                        }),
                      }),
                      (0, i.jsx)("span", {
                        className: "title",
                        children: "Burger",
                      }),
                      (0, i.jsx)("span", {
                        className: "available-item",
                        children: "35+ Burger menu items",
                      }),
                      (0, i.jsxs)("div", {
                        className: "bg-text",
                        children: [
                          (0, i.jsx)("span", { children: "Burger" }),
                          " ",
                          (0, i.jsx)("span", { children: "Burger" }),
                          " ",
                          (0, i.jsx)("span", { children: "Burger" }),
                        ],
                      }),
                    ],
                  }),
                }),
                (0, i.jsx)("div", {
                  className: "col",
                  "data-aos": "fade-up",
                  "data-aos-delay": 50,
                  "data-aos-duration": 1500,
                  "data-aos-offset": 50,
                  children: (0, i.jsxs)("div", {
                    className: "offer-card-item style-two",
                    children: [
                      (0, i.jsx)("img", {
                        src: "assets/images/offer/good-food.png",
                        alt: "Good Food",
                      }),
                      (0, i.jsx)("div", {
                        className: "badge",
                        children: "-10%",
                      }),
                      (0, i.jsx)("div", {
                        className: "image",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/offer/offer-card2.png",
                          alt: "Food",
                        }),
                      }),
                      (0, i.jsx)("span", {
                        className: "title",
                        children: "Pizza",
                      }),
                      (0, i.jsx)("span", {
                        className: "available-item",
                        children: "35+ Burger menu items",
                      }),
                      (0, i.jsxs)("div", {
                        className: "bg-text",
                        children: [
                          (0, i.jsx)("span", { children: "Pizza" }),
                          " ",
                          (0, i.jsx)("span", { children: "Pizza" }),
                          " ",
                          (0, i.jsx)("span", { children: "Pizza" }),
                        ],
                      }),
                    ],
                  }),
                }),
                (0, i.jsx)("div", {
                  className: "col",
                  "data-aos": "fade-up",
                  "data-aos-delay": 100,
                  "data-aos-duration": 1500,
                  "data-aos-offset": 50,
                  children: (0, i.jsxs)("div", {
                    className: "offer-card-item",
                    children: [
                      (0, i.jsx)("img", {
                        src: "assets/images/offer/good-food.png",
                        alt: "Good Food",
                      }),
                      (0, i.jsx)("div", {
                        className: "badge",
                        children: "Hot",
                      }),
                      (0, i.jsx)("div", {
                        className: "image",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/offer/offer-card3.png",
                          alt: "Food",
                        }),
                      }),
                      (0, i.jsx)("span", {
                        className: "title",
                        children: "hotdog",
                      }),
                      (0, i.jsx)("span", {
                        className: "available-item",
                        children: "35+ Burger menu items",
                      }),
                      (0, i.jsxs)("div", {
                        className: "bg-text",
                        children: [
                          (0, i.jsx)("span", { children: "hotdog" }),
                          " ",
                          (0, i.jsx)("span", { children: "hotdog" }),
                          " ",
                          (0, i.jsx)("span", { children: "hotdog" }),
                        ],
                      }),
                    ],
                  }),
                }),
                (0, i.jsx)("div", {
                  className: "col",
                  "data-aos": "fade-up",
                  "data-aos-delay": 150,
                  "data-aos-duration": 1500,
                  "data-aos-offset": 50,
                  children: (0, i.jsxs)("div", {
                    className: "offer-card-item style-two",
                    children: [
                      (0, i.jsx)("img", {
                        src: "assets/images/offer/good-food.png",
                        alt: "Good Food",
                      }),
                      (0, i.jsx)("div", {
                        className: "badge",
                        children: "-15%",
                      }),
                      (0, i.jsx)("div", {
                        className: "image",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/offer/offer-card4.png",
                          alt: "Food",
                        }),
                      }),
                      (0, i.jsx)("span", {
                        className: "title",
                        children: "chickens",
                      }),
                      (0, i.jsx)("span", {
                        className: "available-item",
                        children: "35+ Burger menu items",
                      }),
                      (0, i.jsxs)("div", {
                        className: "bg-text",
                        children: [
                          (0, i.jsx)("span", { children: "chickens" }),
                          " ",
                          (0, i.jsx)("span", { children: "chickens" }),
                          " ",
                          (0, i.jsx)("span", { children: "chickens" }),
                        ],
                      }),
                    ],
                  }),
                }),
                (0, i.jsx)("div", {
                  className: "col",
                  "data-aos": "fade-up",
                  "data-aos-delay": 200,
                  "data-aos-duration": 1500,
                  "data-aos-offset": 50,
                  children: (0, i.jsxs)("div", {
                    className: "offer-card-item",
                    children: [
                      (0, i.jsx)("img", {
                        src: "assets/images/offer/good-food.png",
                        alt: "Good Food",
                      }),
                      (0, i.jsx)("div", {
                        className: "badge",
                        children: "Hot",
                      }),
                      (0, i.jsx)("div", {
                        className: "image",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/offer/offer-card5.png",
                          alt: "Food",
                        }),
                      }),
                      (0, i.jsx)("span", {
                        className: "title",
                        children: "seafood",
                      }),
                      (0, i.jsx)("span", {
                        className: "available-item",
                        children: "35+ Burger menu items",
                      }),
                      (0, i.jsxs)("div", {
                        className: "bg-text",
                        children: [
                          (0, i.jsx)("span", { children: "seafood" }),
                          " ",
                          (0, i.jsx)("span", { children: "seafood" }),
                          " ",
                          (0, i.jsx)("span", { children: "seafood" }),
                        ],
                      }),
                    ],
                  }),
                }),
              ],
            }),
          }),
        r = a(3407),
        d = a(690),
        n = a(7138),
        t = () =>
          (0, i.jsxs)(d.default, {
            children: [
              (0, i.jsxs)("section", {
                className: "hero-area bgs-cover pt-180 rpt-150 pb-100 rel z-1",
                style: {
                  backgroundImage: "url(assets/images/background/hero.jpg)",
                },
                children: [
                  (0, i.jsx)("div", {
                    className: "container",
                    children: (0, i.jsxs)("div", {
                      className: "row align-items-center",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "hero-content text-white",
                            "data-aos": "fade-left",
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsxs)("span", {
                                className: "sub-title mb-35",
                                children: [
                                  (0, i.jsx)("i", {
                                    className: "far fa-hamburger",
                                  }),
                                  " Start price Only $25",
                                ],
                              }),
                              (0, i.jsx)("h1", {
                                children: "delicious food near your town",
                              }),
                              (0, i.jsx)("p", {
                                children:
                                  "Welcome to our culinary sanctuary, where every dish tells a story every bite is an adventure at our food website, we invite",
                              }),
                              (0, i.jsxs)(n.default, {
                                href: "menu-chicken",
                                className: "theme-btn",
                                children: [
                                  "View All Menu ",
                                  (0, i.jsx)("i", {
                                    className: "far fa-arrow-alt-right",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          "data-aos": "fade-right",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: (0, i.jsxs)("div", {
                            className: "hero-images rmt-60",
                            children: [
                              (0, i.jsx)("img", {
                                src: "assets/images/hero/hero-right.png",
                                alt: "Hero",
                              }),
                              (0, i.jsx)("div", {
                                className: "price",
                                children: (0, i.jsx)("img", {
                                  src: "assets/images/hero/price.png",
                                  alt: "Hero",
                                }),
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  }),
                  (0, i.jsxs)("div", {
                    className: "hero-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape1.png",
                          alt: "Hero Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape2.png",
                          alt: "Hero Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape three",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape3.png",
                          alt: "Hero Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape four",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape4.png",
                          alt: "Hero Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape five",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape5.png",
                          alt: "Hero Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("div", {
                className: "headline-area pt-120 rpt-90 rel z-1",
                children: [
                  (0, i.jsxs)("span", {
                    className: "marquee-wrap",
                    children: [
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, i.jsxs)("div", {
                    className: "headline-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/chillies.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/tomato.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("section", {
                className: "about-us-area pt-130 rpt-85 pb-100 rpb-70 rel z-1",
                children: [
                  (0, i.jsx)("div", {
                    className: "container",
                    children: (0, i.jsxs)("div", {
                      className: "row align-items-end",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "about-image-part mb-30 rmb-55",
                            "data-aos": "fade-right",
                            "data-aos-duration": 1500,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "food-review",
                                children: [
                                  (0, i.jsx)("div", {
                                    className: "author",
                                    children: (0, i.jsx)("img", {
                                      src: "assets/images/about/review-author.png",
                                      alt: "Author",
                                    }),
                                  }),
                                  (0, i.jsx)("span", {
                                    className: "text",
                                    children: "Very good food",
                                  }),
                                  (0, i.jsxs)("div", {
                                    className: "ratting",
                                    children: [
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsx)("img", {
                                src: "assets/images/about/about.jpg",
                                alt: "About",
                              }),
                              (0, i.jsxs)("div", {
                                className: "quality-food",
                                style: {
                                  backgroundImage:
                                    "url(assets/images/shapes/about-star.png)",
                                },
                                children: [
                                  (0, i.jsx)("span", {
                                    className: "for-border",
                                  }),
                                  (0, i.jsxs)("span", {
                                    className: "text",
                                    children: [
                                      "quality ",
                                      (0, i.jsx)("br", {}),
                                      "food",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "about-us-content",
                            "data-aos": "fade-left",
                            "data-aos-duration": 1500,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "section-title mb-25",
                                children: [
                                  (0, i.jsx)("span", {
                                    className: "sub-title mb-5",
                                    children: "learn About wellfood",
                                  }),
                                  (0, i.jsx)("h2", {
                                    children:
                                      "the amazing & Quality food for your good health",
                                  }),
                                ],
                              }),
                              (0, i.jsx)("p", {
                                children:
                                  "Welcome too restaurant, where culinary excellence meets warm hospitality in every dish we serve. Nestled in the heart of City Name our eatery invites you on a journey",
                              }),
                              (0, i.jsxs)("div", {
                                className: "about-btn-author pt-5 mb-45",
                                children: [
                                  (0, i.jsxs)(n.default, {
                                    href: "about",
                                    className: "theme-btn style-two",
                                    children: [
                                      "learn more us ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                  (0, i.jsxs)(n.default, {
                                    href: "about",
                                    className: "read-more",
                                    children: [
                                      "Explore popular menu",
                                      " ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "row",
                                children: [
                                  (0, i.jsx)("div", {
                                    className: "col-sm-6",
                                    children: (0, i.jsxs)("div", {
                                      className: "service-item style-two",
                                      children: [
                                        (0, i.jsx)("div", {
                                          className: "icon",
                                          children: (0, i.jsx)("i", {
                                            className: "flaticon-high-quality",
                                          }),
                                        }),
                                        (0, i.jsx)("h5", {
                                          children: (0, i.jsx)(n.default, {
                                            href: "menu-burger",
                                            children: "Best Quality Food",
                                          }),
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Our talented chefs craft each dish precision sourcing",
                                        }),
                                      ],
                                    }),
                                  }),
                                  (0, i.jsx)("div", {
                                    className: "col-sm-6",
                                    children: (0, i.jsxs)("div", {
                                      className: "service-item style-two",
                                      children: [
                                        (0, i.jsx)("div", {
                                          className: "icon",
                                          children: (0, i.jsx)("i", {
                                            className: "flaticon-chef",
                                          }),
                                        }),
                                        (0, i.jsx)("h5", {
                                          children: (0, i.jsx)(n.default, {
                                            href: "menu-burger",
                                            children: "Experience our Chefs",
                                          }),
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Our talented chefs craft each dish precision sourcing",
                                        }),
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  }),
                  (0, i.jsx)("div", {
                    className: "about-shapes",
                    children: (0, i.jsx)("div", {
                      className: "shape one",
                      children: (0, i.jsx)("img", {
                        src: "assets/images/shapes/pizza-three.png",
                        alt: "Shape",
                      }),
                    }),
                  }),
                ],
              }),
              (0, i.jsx)(c, {}),
              (0, i.jsxs)("section", {
                className:
                  "offer-area bgc-black pt-160 rpt-100 pb-150 rpb-120 rel z-1",
                style: {
                  backgroundImage:
                    "url(assets/images/background/offer-dot-bg.png)",
                },
                children: [
                  (0, i.jsxs)("span", {
                    className: "marquee-wrap style-two text-white",
                    children: [
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "special deal",
                      }),
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "special deal",
                      }),
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "special deal",
                      }),
                    ],
                  }),
                  (0, i.jsx)("div", {
                    className: "container",
                    children: (0, i.jsxs)("div", {
                      className: "row align-items-center",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "offer-content text-white rmb-55",
                            "data-aos": "fade-left",
                            "data-aos-delay": 50,
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsx)("img", {
                                src: "assets/images/offer/delicious.png",
                                alt: "Image",
                              }),
                              (0, i.jsx)("h2", {
                                children: "Special deal offer for this week",
                              }),
                              (0, i.jsxs)("h3", {
                                children: [
                                  "grilled beef meat only ",
                                  (0, i.jsx)("span", { children: "$59" }),
                                ],
                              }),
                              (0, i.jsx)("p", {
                                children:
                                  "Restaurant, where culinary excellence meets warm hospitality in every dish we serve nestled in the heart of city",
                              }),
                              (0, i.jsxs)(n.default, {
                                href: "shop",
                                className: "theme-btn",
                                children: [
                                  "order now ",
                                  (0, i.jsx)("i", {
                                    className: "far fa-arrow-alt-right",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "offer-image",
                            "data-aos": "fade-right",
                            "data-aos-delay": 50,
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsx)("img", {
                                src: "assets/images/offer/offer-img.png",
                                alt: "Offer Image",
                              }),
                              (0, i.jsx)("div", {
                                className: "offer-badge",
                                style: {
                                  backgroundImage:
                                    "url(assets/images/shapes/offer-circle-shape.png)",
                                },
                                children: (0, i.jsxs)("span", {
                                  children: [
                                    "only ",
                                    (0, i.jsx)("br", {}),
                                    (0, i.jsx)("span", {
                                      className: "price",
                                      children: "$59",
                                    }),
                                  ],
                                }),
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  }),
                  (0, i.jsxs)("div", {
                    className: "offer-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/offer-shape1.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/offer-shape2.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape three",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/offer-shape3.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("div", {
                className: "headline-area pt-120 rpt-90 rel z-1",
                children: [
                  (0, i.jsxs)("span", {
                    className: "marquee-wrap",
                    children: [
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "delicious foods",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, i.jsxs)("div", {
                    className: "headline-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/chillies.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/tomato.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsx)("section", {
                className:
                  "popular-menu-area pt-105 rpt-85 pb-100 rpb-70 rel z-1",
                children: (0, i.jsxs)("div", {
                  className: "container",
                  children: [
                    (0, i.jsx)("div", {
                      className: "row justify-content-center",
                      children: (0, i.jsx)("div", {
                        className: "col-xl-7 col-lg-8",
                        children: (0, i.jsxs)("div", {
                          className: "section-title text-center mb-50",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("span", {
                              className: "sub-title mb-5",
                              children: "popular menu",
                            }),
                            (0, i.jsx)("h2", {
                              children:
                                "we provide exclusive food based on usa explore our popular food",
                            }),
                          ],
                        }),
                      }),
                    }),
                    (0, i.jsxs)("div", {
                      className: "row justify-content-center",
                      children: [
                        (0, i.jsxs)("div", {
                          className: "col-xl-4 col-lg-6 z-3",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Red king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$25",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Alaskan king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$10",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", { children: "Pizza" }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$22",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Hamburger",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$43",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item mb-30",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "chicken soup",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$77",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, i.jsxs)("div", {
                          className: "col-xl-4 col-lg-6 z-2",
                          "data-aos": "fade-up",
                          "data-aos-delay": 50,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Red king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$25",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Alaskan king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$10",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", { children: "Pizza" }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$22",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Hamburger",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$43",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item mb-30",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "chicken soup",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$77",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, i.jsxs)("div", {
                          className: "col-xl-4 col-lg-6 z-1",
                          "data-aos": "fade-up",
                          "data-aos-delay": 100,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Red king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$25",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Alaskan king Crab",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$10",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", { children: "Pizza" }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$22",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "Hamburger",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$43",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                            (0, i.jsxs)("div", {
                              className: "food-item mb-30",
                              children: [
                                (0, i.jsxs)("div", {
                                  className: "content",
                                  children: [
                                    (0, i.jsxs)("div", {
                                      className: "name-desc",
                                      children: [
                                        (0, i.jsx)("h5", {
                                          children: "chicken soup",
                                        }),
                                        (0, i.jsx)("p", {
                                          children:
                                            "Native to the icy waters of the Pacific",
                                        }),
                                      ],
                                    }),
                                    (0, i.jsx)("div", {
                                      className: "price",
                                      children: (0, i.jsx)("span", {
                                        children: "$77",
                                      }),
                                    }),
                                  ],
                                }),
                                (0, i.jsx)("div", {
                                  className: "image",
                                  children: (0, i.jsx)("img", {
                                    src: "assets/images/food/food1.png",
                                    alt: "Food Image",
                                  }),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              (0, i.jsx)("div", {
                className: "gallery-area rel z-1",
                children: (0, i.jsx)("div", {
                  className: "container-fluid",
                  children: (0, i.jsxs)("div", {
                    className: "row justify-content-center",
                    children: [
                      (0, i.jsx)("div", {
                        className: "col-xl-4 col-sm-6",
                        children: (0, i.jsxs)("div", {
                          className: "gallery-item",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("div", {
                              className: "gallery-image",
                              children: (0, i.jsx)("img", {
                                src: "assets/images/gallery/gallery1.jpg",
                                alt: "Gallery",
                              }),
                            }),
                            (0, i.jsxs)("div", {
                              className: "gallery-content",
                              children: [
                                (0, i.jsx)("h5", {
                                  children: "Spicy awesome pizza",
                                }),
                                (0, i.jsx)("span", {
                                  className: "category",
                                  children: "Burger, Hamburger",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "col-xl-4 col-sm-6",
                        children: (0, i.jsxs)("div", {
                          className: "gallery-item",
                          "data-aos": "fade-up",
                          "data-aos-delay": 50,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("div", {
                              className: "gallery-image",
                              children: (0, i.jsx)("img", {
                                src: "assets/images/gallery/gallery2.jpg",
                                alt: "Gallery",
                              }),
                            }),
                            (0, i.jsxs)("div", {
                              className: "gallery-content",
                              children: [
                                (0, i.jsx)("h5", {
                                  children: "Spicy awesome pizza",
                                }),
                                (0, i.jsx)("span", {
                                  className: "category",
                                  children: "Burger, Hamburger",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "col-xl-4 col-sm-6",
                        children: (0, i.jsxs)("div", {
                          className: "gallery-item",
                          "data-aos": "fade-up",
                          "data-aos-delay": 100,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("div", {
                              className: "gallery-image",
                              children: (0, i.jsx)("img", {
                                src: "assets/images/gallery/gallery3.jpg",
                                alt: "Gallery",
                              }),
                            }),
                            (0, i.jsxs)("div", {
                              className: "gallery-content",
                              children: [
                                (0, i.jsx)("h5", {
                                  children: "Spicy awesome pizza",
                                }),
                                (0, i.jsx)("span", {
                                  className: "category",
                                  children: "Burger, Hamburger",
                                }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                }),
              }),
              (0, i.jsxs)("section", {
                className:
                  "why-choose-area bgc-lighter pt-240 rpt-150 pb-100 rpb-70 rel z-1",
                children: [
                  (0, i.jsxs)("span", {
                    className: "marquee-wrap style-two",
                    children: [
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "Why choose Us",
                      }),
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "Why choose Us",
                      }),
                      (0, i.jsx)("span", {
                        className: "marquee-inner left",
                        children: "Why choose Us",
                      }),
                    ],
                  }),
                  (0, i.jsx)("div", {
                    className: "container",
                    children: (0, i.jsxs)("div", {
                      className: "row align-items-center",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "why-choose-content rmb-30",
                            "data-aos": "fade-up",
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "section-title mb-25",
                                children: [
                                  (0, i.jsx)("span", {
                                    className: "sub-title mb-5",
                                    children: "Why choose us",
                                  }),
                                  (0, i.jsx)("h2", {
                                    children:
                                      "We Offer quality service That Customers Needs",
                                  }),
                                ],
                              }),
                              (0, i.jsx)("p", {
                                children:
                                  "Welcome too restaurant, where culinary excellence meets warm hospitality in every dish we serve. Nestled in the heart of City Name our eatery invites you on a journey",
                              }),
                              (0, i.jsxs)("div", {
                                className: "about-btn-author mb-60",
                                children: [
                                  (0, i.jsxs)(n.default, {
                                    href: "about",
                                    className: "theme-btn",
                                    children: [
                                      "learn more us ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                  (0, i.jsxs)("div", {
                                    className: "author",
                                    children: [
                                      (0, i.jsx)("img", {
                                        src: "assets/images/about/author.jpg",
                                        alt: "Author",
                                      }),
                                      (0, i.jsxs)("h6", {
                                        children: [
                                          "Ben A. Conners / ",
                                          (0, i.jsx)("span", {
                                            children: "CEO & Founder",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "row",
                                children: [
                                  (0, i.jsx)("div", {
                                    className: "col-sm-4 col-6",
                                    children: (0, i.jsxs)("div", {
                                      className:
                                        "counter-item counter-text-wrap",
                                      children: [
                                        (0, i.jsx)("span", {
                                          className: "count-text k-plus",
                                          "data-speed": 3e3,
                                          "data-stop": 34,
                                          children: (0, i.jsx)(l.default, {
                                            end: 34,
                                          }),
                                        }),
                                        (0, i.jsx)("span", {
                                          className: "counter-title",
                                          children: "Organic Planting",
                                        }),
                                      ],
                                    }),
                                  }),
                                  (0, i.jsx)("div", {
                                    className: "col-sm-4 col-6",
                                    children: (0, i.jsxs)("div", {
                                      className:
                                        "counter-item counter-text-wrap",
                                      children: [
                                        (0, i.jsx)("span", {
                                          className: "count-text plus",
                                          "data-speed": 3e3,
                                          "data-stop": 356,
                                          children: (0, i.jsx)(l.default, {
                                            end: 356,
                                          }),
                                        }),
                                        (0, i.jsx)("span", {
                                          className: "counter-title",
                                          children: "Passionate Chef’s",
                                        }),
                                      ],
                                    }),
                                  }),
                                  (0, i.jsx)("div", {
                                    className: "col-sm-4 col-6",
                                    children: (0, i.jsxs)("div", {
                                      className:
                                        "counter-item counter-text-wrap",
                                      children: [
                                        (0, i.jsx)("span", {
                                          className: "count-text plus",
                                          "data-speed": 3e3,
                                          "data-stop": 853,
                                          children: (0, i.jsx)(l.default, {
                                            end: 853,
                                          }),
                                        }),
                                        (0, i.jsx)("span", {
                                          className: "counter-title",
                                          children: "Favourite Dishes",
                                        }),
                                      ],
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-lg-6",
                          children: (0, i.jsxs)("div", {
                            className: "row",
                            children: [
                              (0, i.jsxs)("div", {
                                className: "col-sm-6",
                                "data-aos": "fade-up",
                                "data-aos-delay": 50,
                                "data-aos-duration": 1500,
                                "data-aos-offset": 50,
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "service-item",
                                    children: [
                                      (0, i.jsx)("div", {
                                        className: "icon",
                                        children: (0, i.jsx)("i", {
                                          className:
                                            "flaticon-recommended-food",
                                        }),
                                      }),
                                      (0, i.jsx)("h4", {
                                        children: (0, i.jsx)(n.default, {
                                          href: "menu-burger",
                                          children: "Best Quality Food",
                                        }),
                                      }),
                                      (0, i.jsx)("p", {
                                        children:
                                          "Sed ut perspiciatis unde omnis este natus sit voluptatem",
                                      }),
                                    ],
                                  }),
                                  (0, i.jsxs)("div", {
                                    className: "service-item",
                                    children: [
                                      (0, i.jsx)("div", {
                                        className: "icon",
                                        children: (0, i.jsx)("i", {
                                          className: "flaticon-fast-delivery",
                                        }),
                                      }),
                                      (0, i.jsx)("h4", {
                                        children: (0, i.jsx)(n.default, {
                                          href: "menu-burger",
                                          children: "fast food delivery",
                                        }),
                                      }),
                                      (0, i.jsx)("p", {
                                        children:
                                          "Sed ut perspiciatis unde omnis este natus sit voluptatem",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "col-sm-6",
                                "data-aos": "fade-up",
                                "data-aos-delay": 100,
                                "data-aos-duration": 1500,
                                "data-aos-offset": 50,
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "service-item mt-30 rmt-0",
                                    children: [
                                      (0, i.jsx)("div", {
                                        className: "icon",
                                        children: (0, i.jsx)("i", {
                                          className: "flaticon-cashback",
                                        }),
                                      }),
                                      (0, i.jsx)("h4", {
                                        children: (0, i.jsx)(n.default, {
                                          href: "menu-burger",
                                          children: "money back guarantee",
                                        }),
                                      }),
                                      (0, i.jsx)("p", {
                                        children:
                                          "Sed ut perspiciatis unde omnis este natus sit voluptatem",
                                      }),
                                    ],
                                  }),
                                  (0, i.jsxs)("div", {
                                    className: "service-item",
                                    children: [
                                      (0, i.jsx)("div", {
                                        className: "icon",
                                        children: (0, i.jsx)("i", {
                                          className: "flaticon-dish",
                                        }),
                                      }),
                                      (0, i.jsx)("h4", {
                                        children: (0, i.jsx)(n.default, {
                                          href: "menu-burger",
                                          children: "100% natural food",
                                        }),
                                      }),
                                      (0, i.jsx)("p", {
                                        children:
                                          "Sed ut perspiciatis unde omnis este natus sit voluptatem",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  }),
                  (0, i.jsxs)("div", {
                    className: "headline-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/chillies.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/tomato.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape three",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/pizza.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("div", {
                className: "headline-area bgc-black pt-120 rpt-90 rel z-2",
                children: [
                  (0, i.jsxs)("span", {
                    className: "marquee-wrap white-text",
                    children: [
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "our Testimonials",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "our Testimonials",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                      (0, i.jsxs)("span", {
                        className: "marquee-inner left",
                        children: [
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "Italian pizza",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "our Testimonials",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: "burger king",
                          }),
                          (0, i.jsx)("span", {
                            className: "marquee-item",
                            children: (0, i.jsx)("i", {
                              className: "flaticon-star",
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, i.jsxs)("div", {
                    className: "headline-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/chillies.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/tomato.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("section", {
                className:
                  "testimonials-area bgc-black pt-105 rpt-85 pb-130 rpb-100 rel z-1",
                children: [
                  (0, i.jsxs)("div", {
                    className: "container",
                    children: [
                      (0, i.jsx)("div", {
                        className: "row justify-content-center",
                        children: (0, i.jsx)("div", {
                          className: "col-xl-7 col-lg-8",
                          children: (0, i.jsxs)("div", {
                            className:
                              "section-title text-white text-center mb-50",
                            "data-aos": "fade-up",
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsx)("span", {
                                className: "sub-title mb-5",
                                children: "customer feedback",
                              }),
                              (0, i.jsx)("h2", {
                                children:
                                  "what have lot’s off happy customer explore feedback",
                              }),
                            ],
                          }),
                        }),
                      }),
                      (0, i.jsx)(r.TestimonialSlider2, {}),
                    ],
                  }),
                  (0, i.jsxs)("div", {
                    className: "testimonials-shapes",
                    children: [
                      (0, i.jsx)("div", {
                        className: "shape one",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/hero-shape4.png",
                          alt: "Shape",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        className: "shape two",
                        children: (0, i.jsx)("img", {
                          src: "assets/images/shapes/tomato.png",
                          alt: "Shape",
                        }),
                      }),
                    ],
                  }),
                ],
              }),
              (0, i.jsxs)("section", {
                className: "cta-area py-100 rel z-1",
                children: [
                  (0, i.jsx)("div", {
                    className: "container",
                    children: (0, i.jsx)("div", {
                      className: "row",
                      children: (0, i.jsx)("div", {
                        className: "col-lg-5 col-md-8",
                        children: (0, i.jsxs)("div", {
                          className: "cta-content",
                          children: [
                            (0, i.jsxs)("div", {
                              className: "section-title text-white mb-20",
                              children: [
                                (0, i.jsx)("span", {
                                  className: "sub-title mb-5",
                                  children: "Need any food?",
                                }),
                                (0, i.jsx)("h2", {
                                  children:
                                    "Looking for best quality food or restaurant?",
                                }),
                              ],
                            }),
                            (0, i.jsxs)(n.default, {
                              href: "contact",
                              className: "theme-btn style-two",
                              children: [
                                "get a quote ",
                                (0, i.jsx)("i", {
                                  className: "far fa-arrow-alt-right",
                                }),
                              ],
                            }),
                            (0, i.jsx)("div", {
                              className: "cta-badge",
                              style: {
                                backgroundImage:
                                  "url(assets/images/shapes/cta-shape.png)",
                              },
                              children: (0, i.jsxs)("span", {
                                children: [
                                  "quality",
                                  (0, i.jsx)("br", {}),
                                  " food",
                                ],
                              }),
                            }),
                          ],
                        }),
                      }),
                    }),
                  }),
                  (0, i.jsx)("div", {
                    className: "cta-bg",
                    style: {
                      backgroundImage: "url(assets/images/background/cta.jpg)",
                    },
                  }),
                ],
              }),
              (0, i.jsx)("section", {
                className: "dishes-area pt-130 rpt-100 rel z-1",
                children: (0, i.jsxs)("div", {
                  className: "container",
                  children: [
                    (0, i.jsx)("div", {
                      className: "row justify-content-center",
                      children: (0, i.jsx)("div", {
                        className: "col-lg-12",
                        children: (0, i.jsxs)("div", {
                          className: "section-title text-center mb-50",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("span", {
                              className: "sub-title mb-5",
                              children: "popular dishes",
                            }),
                            (0, i.jsx)("h2", {
                              children: "explore popular menus",
                            }),
                          ],
                        }),
                      }),
                    }),
                    (0, i.jsxs)("div", {
                      className: "row justify-content-center",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-xl-3 col-lg-4 col-sm-6",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: (0, i.jsxs)("div", {
                            className: "product-item-two",
                            children: [
                              (0, i.jsx)("div", {
                                className: "image",
                                children: (0, i.jsx)("img", {
                                  src: "assets/images/dishes/dish1.png",
                                  alt: "Dish",
                                }),
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "ratting",
                                    children: [
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("span", { children: "(5k)" }),
                                    ],
                                  }),
                                  (0, i.jsx)("h5", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "product-details",
                                      children: "fresh chicken burger",
                                    }),
                                  }),
                                  (0, i.jsxs)("span", {
                                    className: "price",
                                    children: [
                                      (0, i.jsx)("del", { children: "$50" }),
                                      " $25",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-xl-3 col-lg-4 col-sm-6",
                          "data-aos": "fade-up",
                          "data-aos-delay": 50,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: (0, i.jsxs)("div", {
                            className: "product-item-two",
                            children: [
                              (0, i.jsx)("div", {
                                className: "image",
                                children: (0, i.jsx)("img", {
                                  src: "assets/images/dishes/dish2.png",
                                  alt: "Dish",
                                }),
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "ratting",
                                    children: [
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("span", { children: "(5k)" }),
                                    ],
                                  }),
                                  (0, i.jsx)("h5", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "product-details",
                                      children: "pizza with mushrooms",
                                    }),
                                  }),
                                  (0, i.jsxs)("span", {
                                    className: "price",
                                    children: [
                                      (0, i.jsx)("del", { children: "$50" }),
                                      " $25",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-xl-3 col-lg-4 col-sm-6",
                          "data-aos": "fade-up",
                          "data-aos-delay": 100,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: (0, i.jsxs)("div", {
                            className: "product-item-two",
                            children: [
                              (0, i.jsx)("div", {
                                className: "image",
                                children: (0, i.jsx)("img", {
                                  src: "assets/images/dishes/dish3.png",
                                  alt: "Dish",
                                }),
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "ratting",
                                    children: [
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("span", { children: "(5k)" }),
                                    ],
                                  }),
                                  (0, i.jsx)("h5", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "product-details",
                                      children: "double burger & fries",
                                    }),
                                  }),
                                  (0, i.jsxs)("span", {
                                    className: "price",
                                    children: [
                                      (0, i.jsx)("del", { children: "$50" }),
                                      " $25",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-xl-3 col-lg-4 col-sm-6",
                          "data-aos": "fade-up",
                          "data-aos-delay": 150,
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: (0, i.jsxs)("div", {
                            className: "product-item-two",
                            children: [
                              (0, i.jsx)("div", {
                                className: "image",
                                children: (0, i.jsx)("img", {
                                  src: "assets/images/dishes/dish4.png",
                                  alt: "Dish",
                                }),
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsxs)("div", {
                                    className: "ratting",
                                    children: [
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("i", {
                                        className: "fas fa-star",
                                      }),
                                      (0, i.jsx)("span", { children: "(5k)" }),
                                    ],
                                  }),
                                  (0, i.jsx)("h5", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "product-details",
                                      children: "fried chicken french",
                                    }),
                                  }),
                                  (0, i.jsxs)("span", {
                                    className: "price",
                                    children: [
                                      (0, i.jsx)("del", { children: "$50" }),
                                      " $25",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              (0, i.jsx)("section", {
                className: "blog-area pt-100 rpt-70 pb-90 rpb-60 rel z-1",
                children: (0, i.jsxs)("div", {
                  className: "container",
                  children: [
                    (0, i.jsx)("div", {
                      className: "row justify-content-center",
                      children: (0, i.jsx)("div", {
                        className: "col-lg-12",
                        children: (0, i.jsxs)("div", {
                          className: "section-title text-center mb-50",
                          "data-aos": "fade-up",
                          "data-aos-duration": 1500,
                          "data-aos-offset": 50,
                          children: [
                            (0, i.jsx)("span", {
                              className: "sub-title mb-5",
                              children: "latest news & blog",
                            }),
                            (0, i.jsx)("h2", {
                              children: "get every single updates latest",
                            }),
                          ],
                        }),
                      }),
                    }),
                    (0, i.jsxs)("div", {
                      className: "row justify-content-center",
                      children: [
                        (0, i.jsx)("div", {
                          className: "col-xl-4 col-md-6",
                          children: (0, i.jsxs)("div", {
                            className: "blog-item",
                            "data-aos": "fade-up",
                            "data-aos-delay": 50,
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "image",
                                children: [
                                  (0, i.jsx)("img", {
                                    src: "assets/images/blog/blog1.jpg",
                                    alt: "Blog",
                                  }),
                                  (0, i.jsxs)("ul", {
                                    className: "blog-meta",
                                    children: [
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "Quality Food",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "March 25, 2024",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "comments (5)",
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsx)("h4", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "blog-details",
                                      children:
                                        "Culinary Chronicles Exploring Gastronomic Wonders at foodking Restaurant",
                                    }),
                                  }),
                                  (0, i.jsx)("p", {
                                    children:
                                      "Restaurant where culinary excellence meets hospitality in every dish we serve settled in the heart",
                                  }),
                                  (0, i.jsxs)(n.default, {
                                    href: "blog-details",
                                    className: "read-more",
                                    children: [
                                      "Read more ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-xl-4 col-md-6",
                          children: (0, i.jsxs)("div", {
                            className: "blog-item",
                            "data-aos": "fade-up",
                            "data-aos-delay": 100,
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "image",
                                children: [
                                  (0, i.jsx)("img", {
                                    src: "assets/images/blog/blog2.jpg",
                                    alt: "Blog",
                                  }),
                                  (0, i.jsxs)("ul", {
                                    className: "blog-meta",
                                    children: [
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "Quality Food",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "March 25, 2024",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "comments (5)",
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsx)("h4", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "blog-details",
                                      children:
                                        "Culinary Chronicles Exploring Gastronomic Wonders at foodking Restaurant",
                                    }),
                                  }),
                                  (0, i.jsx)("p", {
                                    children:
                                      "Restaurant where culinary excellence meets hospitality in every dish we serve settled in the heart",
                                  }),
                                  (0, i.jsxs)(n.default, {
                                    href: "blog-details",
                                    className: "read-more",
                                    children: [
                                      "Read more ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: "col-xl-4 col-md-6",
                          children: (0, i.jsxs)("div", {
                            className: "blog-item",
                            "data-aos": "fade-up",
                            "data-aos-delay": 150,
                            "data-aos-duration": 1500,
                            "data-aos-offset": 50,
                            children: [
                              (0, i.jsxs)("div", {
                                className: "image",
                                children: [
                                  (0, i.jsx)("img", {
                                    src: "assets/images/blog/blog3.jpg",
                                    alt: "Blog",
                                  }),
                                  (0, i.jsxs)("ul", {
                                    className: "blog-meta",
                                    children: [
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "Quality Food",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "March 25, 2024",
                                        }),
                                      }),
                                      (0, i.jsx)("li", {
                                        children: (0, i.jsx)("a", {
                                          href: "#",
                                          children: "comments (5)",
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, i.jsxs)("div", {
                                className: "content",
                                children: [
                                  (0, i.jsx)("h4", {
                                    children: (0, i.jsx)(n.default, {
                                      href: "blog-details",
                                      children:
                                        "Culinary Chronicles Exploring Gastronomic Wonders at foodking Restaurant",
                                    }),
                                  }),
                                  (0, i.jsx)("p", {
                                    children:
                                      "Restaurant where culinary excellence meets hospitality in every dish we serve settled in the heart",
                                  }),
                                  (0, i.jsxs)(n.default, {
                                    href: "blog-details",
                                    className: "read-more",
                                    children: [
                                      "Read more ",
                                      (0, i.jsx)("i", {
                                        className: "far fa-arrow-alt-right",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            ],
          });
    },
    7887: function (s, e, a) {
      "use strict";
      var i = a(7437),
        l = a(7095),
        c = a(3781),
        r = a.n(c);
      e.default = (s) => {
        let { end: e, decimals: a, extraClass: c } = s;
        return (0, i.jsx)(l.ZP, {
          end: e || 100,
          duration: 3,
          decimals: a || 0,
          children: (s) => {
            let { countUpRef: a, start: l } = s;
            return (0, i.jsx)(r(), {
              onChange: l,
              delayedCall: !0,
              children: (0, i.jsx)("span", {
                className: "".concat(c),
                "data-from": "0",
                "data-to": e,
                ref: a,
                children: "count",
              }),
            });
          },
        });
      };
    },
  },
  function (s) {
    s.O(0, [4882, 5548, 3153, 690, 5503, 2971, 7023, 1744], function () {
      return s((s.s = 1390));
    }),
      (_N_E = s.O());
  },
]);
